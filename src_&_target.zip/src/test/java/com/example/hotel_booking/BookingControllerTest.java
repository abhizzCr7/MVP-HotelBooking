package com.example.hotel_booking;


import com.example.hotel_booking.controller.BookingController;
import com.example.hotel_booking.model.Booking;
import com.example.hotel_booking.model.Hotel;
import com.example.hotel_booking.service.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Date;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BookingController.class)
public class BookingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookingService bookingService;

    private Booking booking1;
    private Booking booking2;

    @BeforeEach
    public void setup() {
        Hotel hotel = new Hotel();
        hotel.setId(1L);

        booking1 = new Booking();
        booking1.setId(1L);
        booking1.setHotel(hotel);
        booking1.setCheckInDate(new Date());
        booking1.setCheckOutDate(new Date());

        booking2 = new Booking();
        booking2.setId(2L);
        booking2.setHotel(hotel);
        booking2.setCheckInDate(new Date());
        booking2.setCheckOutDate(new Date());
    }

    @Test
    public void testGetAllBookings() throws Exception {
        Mockito.when(bookingService.getAllBookings()).thenReturn(Arrays.asList(booking1, booking2));

        mockMvc.perform(get("/api/bookings/bookingsList"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[1].id").value(2L));
    }

    @Test
    public void testGetBookingById() throws Exception {
        Mockito.when(bookingService.getBookingById(1L)).thenReturn(Optional.of(booking1));

        mockMvc.perform(get("/api/bookings/bookingsList/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testCreateBooking() throws Exception {
        Mockito.when(bookingService.createBooking(any(Booking.class))).thenReturn(booking1);

        mockMvc.perform(post("/api/bookings/newBooking")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"hotel\":{\"id\":1},\"checkInDate\":\"2024-07-01\",\"checkOutDate\":\"2024-07-05\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testUpdateBooking() throws Exception {
        Mockito.when(bookingService.updateBooking(anyLong(), any(Booking.class))).thenReturn(Optional.of(booking1));

        mockMvc.perform(put("/api/bookings/newBooking/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"hotel\":{\"id\":1},\"checkInDate\":\"2024-07-01\",\"checkOutDate\":\"2024-07-05\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testDeleteBooking() throws Exception {
        Mockito.when(bookingService.deleteBooking(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/bookings/cancelBooking/1"))
                .andExpect(status().isNoContent());
    }
}