package com.example.hotel_booking;

import com.example.hotel_booking.controller.HotelController;
import com.example.hotel_booking.model.Hotel;
import com.example.hotel_booking.service.HotelService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(HotelController.class)
public class HotelControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private HotelService hotelService;

    private Hotel hotel1;
    private Hotel hotel2;

    @BeforeEach
    public void setup() {
        hotel1 = new Hotel();
        hotel1.setId(1L);
        hotel1.setName("Hotel A");
        hotel1.setAddress("123 Street");
        hotel1.setCity("CityA");
        hotel1.setCountry("CountryA");
        hotel1.setDescription("Description A");


        hotel2 = new Hotel();
        hotel2.setId(2L);
        hotel2.setName("Hotel B");
        hotel2.setAddress("456 Avenue");
        hotel2.setCity("CityB");
        hotel2.setCountry("CountryB");
        hotel2.setDescription("Description B");

    }

    @Test
    public void testGetAllHotels() throws Exception {
        Mockito.when(hotelService.getAllHotels()).thenReturn(Arrays.asList(hotel1, hotel2));

        mockMvc.perform(get("/api/hotels/hotelsList"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[1].id").value(2L));
    }

    @Test
    public void testGetHotelById() throws Exception {
        Mockito.when(hotelService.getHotelById(1L)).thenReturn(Optional.of(hotel1));

        mockMvc.perform(get("/api/hotels/hotelsList/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testCreateHotel() throws Exception {
        Mockito.when(hotelService.createHotel(any(Hotel.class))).thenReturn(hotel1);

        mockMvc.perform(post("/api/hotels/newHotel")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Hotel A\",\"address\":\"123 Street\",\"city\":\"CityA\",\"country\":\"CountryA\",\"description\":\"Description A\"]}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testUpdateHotel() throws Exception {
        Mockito.when(hotelService.updateHotel(anyLong(), any(Hotel.class))).thenReturn(Optional.of(hotel1));

        mockMvc.perform(put("/api/hotels/newHotel/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Hotel A\",\"address\":\"123 Street\",\"city\":\"CityA\",\"country\":\"CountryA\",\"description\":\"Description A\""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }

    @Test
    public void testDeleteHotel() throws Exception {
        Mockito.when(hotelService.deleteHotel(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/hotels/deleteHotel/1"))
                .andExpect(status().isNoContent());
    }
}
