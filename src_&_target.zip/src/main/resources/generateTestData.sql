
#Script for additional data

-- Create Hotels
INSERT INTO hotel (id, name, address, city, country, description)
VALUES
  (1, 'Hotel A', '123 Street', 'CityA', 'CountryA', 'Description A'),
  (2, 'Hotel B', '456 Avenue', 'CityB', 'CountryB', 'Description B'),
  (3, 'Hotel C', '789 Boulevard', 'CityC', 'CountryC', 'Description C'),
  (4, 'Hotel D', '101 Road', 'CityD', 'CountryD', 'Description D'),
  (5, 'Hotel E', '202 Highway', 'CityE', 'CountryE', 'Description E');


-- Create Bookings
INSERT INTO booking (id, hotel_id, check_in_date, check_out_date)
VALUES
  (1, 1, '2024-07-01', '2024-07-05'),
  (2, 2, '2024-07-02', '2024-07-06'),
  (3, 3, '2024-07-03', '2024-07-07'),
  (4, 4, '2024-07-04', '2024-07-08'),
  (5, 5, '2024-07-05', '2024-07-09'),
  (6, 1, '2024-07-06', '2024-07-10'),
  (7, 2, '2024-07-07', '2024-07-11'),
  (8, 3, '2024-07-08', '2024-07-12'),
  (9, 4, '2024-07-09', '2024-07-13'),
  (10, 5, '2024-07-10', '2024-07-14');
